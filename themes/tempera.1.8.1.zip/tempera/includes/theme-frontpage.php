<?php

/** this file is no longer used since 1.8.0
 *  its contents have been merged into includes/custom-styles.php & frontpage.php 
 */
	 